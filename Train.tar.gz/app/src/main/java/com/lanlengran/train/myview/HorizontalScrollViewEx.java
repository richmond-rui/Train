package com.lanlengran.train.myview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Scroller;

/**
 * Created by 芮勤 on 18-10-16 15:03
 */
public class HorizontalScrollViewEx extends ViewGroup{
    private static final String TAG = "HorizontalScrollViewEx";
    private int mChildrenSize;
    private int mChildWidth;
    private int mChildIndex;

    private int mLastX=0;
    private int mLastY=0;

    private int mLastXIntercept=0;
    private int mLastYIntercept=0;

    private Scroller mScroller;
    private VelocityTracker mVelocityTracker;

    public HorizontalScrollViewEx(Context context) {
        super(context);
        init();
    }


    public HorizontalScrollViewEx(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public HorizontalScrollViewEx(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int childLeft=0;
        final int childCount=getChildCount();
        mChildrenSize=childCount;
        for (int i=0;i<childCount;i++){
            final View childView=getChildAt(i);
           // if (childView.get)
        }
    }

    private void init() {
        if (mScroller==null){
            mScroller=new Scroller(getContext());
            mVelocityTracker=VelocityTracker.obtain();
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int measuredWidth=0;
        int measuredHeight=0;
        final int childCount=getChildCount();
        measureChildren(widthMeasureSpec,heightMeasureSpec);
        int widthSpaceSize=MeasureSpec.getSize(widthMeasureSpec);
        int widthSpecMode=MeasureSpec.getMode(widthMeasureSpec);
        int heightSpaceSize=MeasureSpec.getSize(heightMeasureSpec);
        int heightSpecMode=MeasureSpec.getMode(heightMeasureSpec);

        if (childCount==0){
            setMeasuredDimension(0,0);
        }else if (widthSpecMode==MeasureSpec.AT_MOST&&heightSpecMode==MeasureSpec.AT_MOST){
            final View childView=getChildAt(0);
            measuredWidth=childView.getMeasuredWidth()*childCount; //默认每个子元素的宽高一样
            measuredHeight=childView.getMeasuredHeight();
            setMeasuredDimension(measuredWidth,measuredHeight);
        }else if (heightSpecMode==MeasureSpec.AT_MOST){
            final View childView=getChildAt(0);
            measuredHeight=childView.getMeasuredHeight();
            setMeasuredDimension(widthSpaceSize,measuredHeight);
        }else if (widthSpecMode==MeasureSpec.AT_MOST){
            final View childView=getChildAt(0);
            measuredWidth=childView.getMeasuredWidth()*childCount; //默认每个子元素的宽高一样
            setMeasuredDimension(measuredWidth,heightSpaceSize);
        }

    }

    @Override
    public void computeScroll() {
        super.computeScroll();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

}
