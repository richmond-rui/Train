package com.lanlengran.train.myview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.lanlengran.train.R;

public class MyViewTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_view_test);
    }
}
